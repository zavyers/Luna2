"""Read-only system information (CPU, RAM, disk, battery). Safe: it changes nothing."""
from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any, Dict, Optional

try:  # psutil is in requirements.txt, but Luna must still start without it.
    import psutil
except ImportError:  # pragma: no cover
    psutil = None


def _pct(value: Optional[float]) -> Optional[int]:
    return None if value is None else max(0, min(100, int(round(value))))


def get_system_info() -> Dict[str, Any]:
    """Percentages are ints 0-100, or None when this machine can't report them."""
    info: Dict[str, Any] = {"cpu": None, "ram": None, "disk": None, "battery": None, "charging": None}

    if psutil is not None:
        try:
            info["cpu"] = _pct(psutil.cpu_percent(interval=None))
            info["ram"] = _pct(psutil.virtual_memory().percent)
        except Exception:
            pass
        try:
            battery = psutil.sensors_battery()
            if battery is not None:
                info["battery"] = _pct(battery.percent)
                info["charging"] = bool(battery.power_plugged)
        except Exception:
            pass

    try:
        anchor = Path.home().anchor or "/"
        usage = shutil.disk_usage(anchor)
        info["disk"] = _pct(usage.used / usage.total * 100)
    except OSError:
        pass
    return info
