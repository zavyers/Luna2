"""Local server behind Luna's window.

The UI is a web page shown in a native window. It talks to this server over 127.0.0.1
only. Every API call needs a random per-launch token, and the Host/Origin headers are
checked, so other websites or programs cannot drive Luna through the browser.
"""
from __future__ import annotations

import hmac
import json
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple

from app.agent import Assistant
from app.ai import AIError, GeminiService
from app.chat.store import ChatStore, StoreError
from app.config import Settings, missing_key_message
from app.tools.system_info import get_system_info

WEB_DIR = Path(__file__).resolve().parent / "web"
TOKEN_PLACEHOLDER = "__LUNA_TOKEN__"
MAX_BODY = 64 * 1024
MAX_MESSAGE_CHARS = 8000

CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
}


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.status = status


class LunaApp:
    """All API methods. Each takes a dict and returns a JSON-serialisable dict."""

    def __init__(self, settings: Settings, store: ChatStore, assistant: Assistant) -> None:
        self.settings = settings
        self.store = store
        self.assistant = assistant
        self.token = secrets.token_urlsafe(24)
        self._connection: Dict[str, Any] = {"state": "unknown", "detail": ""}

    # -- helpers -------------------------------------------------------------

    @staticmethod
    def _str(args: Dict[str, Any], name: str, required: bool = True, limit: int = 200) -> Optional[str]:
        value = args.get(name)
        if value is None:
            if required:
                raise ApiError(f"Missing '{name}'.")
            return None
        if not isinstance(value, str):
            raise ApiError(f"'{name}' must be text.")
        if len(value) > limit:
            raise ApiError(f"'{name}' is too long.")
        return value

    def _chat_payload(self, chat_id: str) -> Dict[str, Any]:
        chat = self.store.get_chat(chat_id)
        project = self.store.get_project(chat.project_id) if chat.project_id else None
        return {
            "id": chat.id,
            "title": chat.title,
            "project": {"id": project.id, "name": project.name} if project else None,
            "messages": self.store.messages(chat_id),
        }

    # -- API methods ---------------------------------------------------------

    def status(self, _: Dict[str, Any]) -> Dict[str, Any]:
        if not self.settings.has_api_key:
            gemini = "missing_key"
        else:
            gemini = self._connection["state"] if self._connection["state"] != "unknown" else "configured"
        return {
            "gemini": gemini,
            "gemini_detail": self._connection["detail"],
            "model": self.settings.gemini_model,
            "env_file": str(self.settings.env_file),
            "setup_message": missing_key_message(self.settings.env_file) if gemini == "missing_key" else "",
        }

    def test_connection(self, _: Dict[str, Any]) -> Dict[str, Any]:
        if not self.settings.has_api_key:
            self._connection = {"state": "missing_key", "detail": ""}
            return self.status({})
        try:
            self.assistant.provider.check_connection()
        except AIError as error:
            self._connection = {"state": "error", "detail": str(error)}
            self.assistant.log("error", str(error))
        else:
            self._connection = {"state": "ready", "detail": ""}
            self.assistant.log("gemini", "Connection test passed")
        return self.status({})

    def system(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return get_system_info()

    def activity(self, _: Dict[str, Any]) -> Dict[str, Any]:
        return {"items": self.assistant.activity()}

    def overview(self, args: Dict[str, Any]) -> Dict[str, Any]:
        return self.store.overview(
            self._str(args, "query", required=False) or "",
            self._str(args, "keep_id", required=False) or None,
        )

    def open_chat(self, args: Dict[str, Any]) -> Dict[str, Any]:
        return self._chat_payload(self._str(args, "chat_id"))

    def start(self, _: Dict[str, Any]) -> Dict[str, Any]:
        """Chat to show when Luna opens: a fresh one (an existing empty chat is reused).
        Earlier conversations stay one click away in the menu."""
        return self._chat_payload(self.store.new_chat().id)

    def new_chat(self, args: Dict[str, Any]) -> Dict[str, Any]:
        project_id = self._str(args, "project_id", required=False)
        chat = self.store.new_chat(project_id or None)
        self.assistant.log("chat", "Started a new chat")
        return self._chat_payload(chat.id)

    def new_project(self, args: Dict[str, Any]) -> Dict[str, Any]:
        chat = self.store.new_project(self._str(args, "name", required=False) or None)
        project = self.store.get_project(chat.project_id)
        self.assistant.log("project", f"Created project “{project.name}”")
        return self._chat_payload(chat.id)

    def rename_chat(self, args: Dict[str, Any]) -> Dict[str, Any]:
        self.store.rename_chat(self._str(args, "chat_id"), self._str(args, "title"))
        return {"ok": True}

    def rename_project(self, args: Dict[str, Any]) -> Dict[str, Any]:
        self.store.rename_project(self._str(args, "project_id"), self._str(args, "name"))
        return {"ok": True}

    def delete_chat(self, args: Dict[str, Any]) -> Dict[str, Any]:
        self.store.delete_chat(self._str(args, "chat_id"))
        self.assistant.log("chat", "Deleted a chat")
        return {"ok": True}

    def delete_project(self, args: Dict[str, Any]) -> Dict[str, Any]:
        removed = self.store.delete_project(self._str(args, "project_id"))
        self.assistant.log("project", f"Deleted a project and {removed} chat(s)")
        return {"ok": True, "removed_chats": removed}

    def send(self, args: Dict[str, Any]) -> Dict[str, Any]:
        text = self._str(args, "text", limit=MAX_MESSAGE_CHARS)
        chat_id = self._str(args, "chat_id", required=False) or None
        reply = self.assistant.handle(chat_id, text)
        payload: Dict[str, Any] = {
            "ok": reply.ok,
            "text": reply.text,
            "action": reply.action,
            "error_kind": reply.error_kind,
            "restore_text": reply.restore_text,
        }
        if reply.chat_id:
            payload["chat"] = self._chat_payload(reply.chat_id)
        return payload

    METHODS = (
        "status", "test_connection", "system", "activity", "overview", "open_chat", "start",
        "new_chat", "new_project", "rename_chat", "rename_project", "delete_chat",
        "delete_project", "send",
    )

    def call(self, method: str, args: Dict[str, Any]) -> Dict[str, Any]:
        if method not in self.METHODS:
            raise ApiError("Unknown request.", 404)
        try:
            return getattr(self, method)(args)
        except StoreError as error:
            raise ApiError(str(error), 404) from None


def build_app(settings: Settings, store: Optional[ChatStore] = None, provider: Any = None) -> LunaApp:
    store = store or ChatStore()
    provider = provider or GeminiService(settings)
    return LunaApp(settings, store, Assistant(store, provider, settings))


def _make_handler(app: LunaApp, allowed_hosts: Tuple[str, ...]) -> type:
    class Handler(BaseHTTPRequestHandler):
        server_version = "Luna"
        protocol_version = "HTTP/1.1"

        def log_message(self, *_: Any) -> None:  # keep the console quiet (and key-free)
            pass

        # ------------------------------------------------------------ plumbing

        def _host_ok(self) -> bool:
            return (self.headers.get("Host") or "") in allowed_hosts

        def _send(self, status: int, body: bytes, content_type: str) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header(
                "Content-Security-Policy",
                "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                "connect-src 'self'; frame-ancestors 'none'",
            )
            self.end_headers()
            self.wfile.write(body)

        def _json(self, status: int, payload: Dict[str, Any]) -> None:
            self._send(status, json.dumps(payload).encode("utf-8"), "application/json")

        # ----------------------------------------------------------------- GET

        def do_GET(self) -> None:
            if not self._host_ok():
                return self._json(403, {"error": "Forbidden."})
            path = self.path.split("?", 1)[0]
            if path == "/":
                path = "/index.html"
            target = (WEB_DIR / path.lstrip("/")).resolve()
            if WEB_DIR not in target.parents or not target.is_file() or target.suffix not in CONTENT_TYPES:
                return self._json(404, {"error": "Not found."})
            data = target.read_bytes()
            if target.name == "index.html":
                data = data.replace(TOKEN_PLACEHOLDER.encode(), app.token.encode())
            self._send(200, data, CONTENT_TYPES[target.suffix])

        # ---------------------------------------------------------------- POST

        def do_POST(self) -> None:
            if not self._host_ok():
                return self._json(403, {"error": "Forbidden."})
            origin = self.headers.get("Origin")
            if origin is not None and origin.split("://", 1)[-1] not in allowed_hosts:
                return self._json(403, {"error": "Forbidden."})
            supplied = self.headers.get("X-Luna-Token") or ""
            if not hmac.compare_digest(supplied, app.token):
                return self._json(403, {"error": "Forbidden."})
            if not self.path.startswith("/api/"):
                return self._json(404, {"error": "Not found."})

            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = -1
            if length < 0 or length > MAX_BODY:
                return self._json(413, {"error": "Request too large."})
            try:
                raw = self.rfile.read(length) if length else b"{}"
                args = json.loads(raw.decode("utf-8"))
                if not isinstance(args, dict):
                    raise ValueError
            except (ValueError, UnicodeDecodeError):
                return self._json(400, {"error": "Invalid request."})

            try:
                result = app.call(self.path[len("/api/"):], args)
            except ApiError as error:
                return self._json(error.status, {"error": str(error)})
            except Exception:  # never leak internals (or secrets) to the page
                return self._json(500, {"error": "Something went wrong inside Luna."})
            self._json(200, result)

    return Handler


class LunaServer:
    def __init__(self, app: LunaApp, port: int = 0) -> None:
        self.app = app
        self._httpd = ThreadingHTTPServer(("127.0.0.1", port), _make_handler(app, ()))
        self.port = self._httpd.server_address[1]
        hosts = (f"127.0.0.1:{self.port}", f"localhost:{self.port}")
        self._httpd.RequestHandlerClass = _make_handler(app, hosts)
        self._httpd.daemon_threads = True
        self._thread: Optional[threading.Thread] = None

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}/"

    def start(self) -> None:
        self._thread = threading.Thread(target=self._httpd.serve_forever, name="luna-ui", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._httpd.shutdown()
        self._httpd.server_close()
