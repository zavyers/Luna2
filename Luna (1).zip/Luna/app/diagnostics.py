"""Startup self-check: `python main.py --check` (or `python -m app.diagnostics`).

Prints whether the .env file and Gemini key are set up and whether Gemini answers.
Never prints the key.
"""
from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import List, Optional

from app.ai import AIError, AIProvider, GeminiService
from app.config import Settings, load_settings, missing_key_message


@dataclass(frozen=True)
class CheckResult:
    name: str
    ok: bool
    detail: str


def run_checks(
    settings: Optional[Settings] = None, provider: Optional[AIProvider] = None
) -> List[CheckResult]:
    settings = settings or load_settings()
    results: List[CheckResult] = []

    results.append(
        CheckResult(
            ".env file",
            settings.env_file.is_file(),
            str(settings.env_file) if settings.env_file.is_file() else "not found",
        )
    )

    if not settings.has_api_key:
        results.append(CheckResult("Gemini API key", False, "missing (see setup steps below)"))
        return results
    results.append(CheckResult("Gemini API key", True, "found (hidden)"))

    provider = provider or GeminiService(settings)
    try:
        provider.check_connection()
    except AIError as error:
        results.append(CheckResult("Gemini connection", False, str(error)))
    else:
        results.append(
            CheckResult("Gemini connection", True, f"model '{settings.gemini_model}' reachable")
        )
    return results


def format_report(results: List[CheckResult], settings: Optional[Settings] = None) -> str:
    lines = ["Luna self-check", "---------------"]
    for result in results:
        mark = "OK  " if result.ok else "FAIL"
        lines.append(f"[{mark}] {result.name}: {result.detail}")
    settings = settings or load_settings()
    if not settings.has_api_key:
        lines += ["", missing_key_message(settings.env_file)]
    return "\n".join(lines)


def main() -> int:
    settings = load_settings()
    results = run_checks(settings)
    print(format_report(results, settings))
    return 0 if all(r.ok for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
