"""The assistant: routes each request to a local command or to Gemini, keeps the
conversation context, and records everything in the local chat store."""
from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional

from app.ai import AIError, AIProvider, ChatMessage, MissingAPIKeyError
from app.chat import ChatStore
from app.config import Settings, missing_key_message

from .commands import Command, parse_command

# How many recent messages are sent to Gemini so follow-ups ("when was it?") make sense.
CONTEXT_MESSAGES = 24

SYSTEM_INSTRUCTION = (
    "You are Luna, a personal AI assistant running as a desktop app on the user's Windows "
    "laptop. Be warm, concise and natural, because your replies may be spoken aloud: prefer "
    "short paragraphs over long lists and avoid heavy markdown. Use the earlier messages to "
    "resolve follow-up questions such as 'when was it?'.\n"
    "Right now you can ONLY hold a conversation. You cannot yet open apps, control the "
    "computer, search the web, set timers or reminders, or read files. If asked to do one of "
    "those, say plainly that you can't do it yet and never claim an action was performed. "
    "You do not have live information such as today's news or weather; say so instead of "
    "guessing. Never mention or reveal any API key or configuration secrets."
)


@dataclass
class Reply:
    ok: bool
    text: str = ""
    chat_id: Optional[str] = None
    action: Optional[str] = None  # "new_chat" | "new_project" when a local command ran
    error_kind: Optional[str] = None  # "missing_key" | "ai" when ok is False
    restore_text: Optional[str] = None  # the user's text, handed back so they can retry


@dataclass
class ActivityEntry:
    ts: float
    kind: str
    detail: str


class Assistant:
    def __init__(self, store: ChatStore, provider: AIProvider, settings: Settings) -> None:
        self.store = store
        self.provider = provider
        self.settings = settings
        self._activity: Deque[ActivityEntry] = deque(maxlen=50)
        self._lock = threading.Lock()

    # -------------------------------------------------------------- activity log

    def log(self, kind: str, detail: str) -> None:
        with self._lock:
            self._activity.appendleft(ActivityEntry(time.time(), kind, detail))

    def activity(self, limit: int = 12) -> List[Dict[str, Any]]:
        with self._lock:
            return [
                {"ts": e.ts, "kind": e.kind, "detail": e.detail}
                for e in list(self._activity)[:limit]
            ]

    # -------------------------------------------------------------- main entry

    def handle(self, chat_id: Optional[str], text: str) -> Reply:
        text = (text or "").strip()
        if not text:
            return Reply(ok=False, text="Say or type something first.", error_kind="ai")

        command = parse_command(text)
        if command is not None:
            return self._run_command(command)

        if chat_id is None:
            chat_id = self.store.new_chat().id
        else:
            self.store.get_chat(chat_id)  # raises a clear StoreError if it vanished

        if not self.settings.has_api_key:
            return Reply(
                ok=False,
                text=missing_key_message(self.settings.env_file),
                chat_id=chat_id,
                error_kind="missing_key",
                restore_text=text,
            )

        self.store.add_message(chat_id, "user", text)
        history = self.store.messages(chat_id)[-CONTEXT_MESSAGES:]
        messages = [ChatMessage(m["role"], m["text"]) for m in history]
        started = time.time()
        try:
            response = self.provider.generate(messages, system_instruction=SYSTEM_INSTRUCTION)
        except MissingAPIKeyError:
            self.store.remove_last_message(chat_id, "user")
            return Reply(
                ok=False,
                text=missing_key_message(self.settings.env_file),
                chat_id=chat_id,
                error_kind="missing_key",
                restore_text=text,
            )
        except AIError as error:
            self.store.remove_last_message(chat_id, "user")
            self.log("error", str(error))
            return Reply(ok=False, text=str(error), chat_id=chat_id, error_kind="ai", restore_text=text)

        self.store.add_message(chat_id, "assistant", response.text)
        self.log("gemini", f"Answered in {time.time() - started:.1f}s")
        return Reply(ok=True, text=response.text, chat_id=chat_id)

    # ---------------------------------------------------------------- commands

    def _run_command(self, command: Command) -> Reply:
        if command.name == "new_chat":
            chat = self.store.new_chat()
            self.log("chat", "Started a new chat")
            return Reply(ok=True, text="New chat ready.", chat_id=chat.id, action="new_chat")
        if command.name == "new_project":
            chat = self.store.new_project(command.argument)
            project = self.store.get_project(chat.project_id) if chat.project_id else None
            name = project.name if project else "project"
            self.log("project", f"Created project “{name}”")
            return Reply(
                ok=True,
                text=f"Started “{name}” with a fresh chat.",
                chat_id=chat.id,
                action="new_project",
            )
        return Reply(ok=False, text="I don't know that command.", error_kind="ai")
