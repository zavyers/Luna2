"""Provider-neutral AI interface.

Luna talks to this interface, not to Gemini directly, so the provider can be swapped
later without rewriting the rest of the application. Only Gemini is implemented.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional


class AIError(Exception):
    """Base class. str(error) is always safe to show to the user (contains no secrets)."""


class MissingAPIKeyError(AIError):
    pass


class InvalidAPIKeyError(AIError):
    pass


class AINetworkError(AIError):
    pass


class AITimeoutError(AIError):
    pass


class AIRateLimitError(AIError):
    pass


class AIResponseError(AIError):
    """The service answered, but not with a usable result (blocked, empty, malformed)."""


@dataclass(frozen=True)
class ChatMessage:
    role: str  # "user" or "assistant"
    text: str


@dataclass(frozen=True)
class AIResponse:
    text: str
    provider: str = ""
    model: str = ""
    finish_reason: Optional[str] = None


class AIProvider(ABC):
    name: str = "provider"

    @abstractmethod
    def generate(
        self, messages: List[ChatMessage], system_instruction: Optional[str] = None
    ) -> AIResponse:
        """Return the model's reply to the conversation. Raises AIError subclasses."""

    @abstractmethod
    def check_connection(self) -> None:
        """Verify the key and model work without spending tokens. Raises AIError on failure."""
