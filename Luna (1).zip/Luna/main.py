"""Luna: start with `python main.py`.

    python main.py            open Luna in her own window
    python main.py --browser  open Luna in your default web browser instead
    python main.py --check    check the .env file and the Gemini connection, then exit
"""
from __future__ import annotations

import argparse
import sys
import threading
import webbrowser

from app.config import load_settings, missing_key_message


def _open_window(url: str) -> bool:
    """Show the UI in a native window. Returns False if that isn't possible."""
    try:
        import webview  # pywebview; uses Microsoft Edge WebView2 on Windows 10/11
    except ImportError:
        return False
    try:
        webview.create_window("Luna", url, width=1360, height=800, min_size=(1000, 640), background_color="#050b14")
        webview.start()
        return True
    except Exception as error:  # e.g. WebView2 runtime missing
        print(f"Luna couldn't open her window ({type(error).__name__}). Using your browser instead.")
        return False


def main() -> int:
    parser = argparse.ArgumentParser(prog="luna", description="Luna, your Gemini-powered assistant.")
    parser.add_argument("--check", action="store_true", help="check setup and the Gemini connection")
    parser.add_argument("--browser", action="store_true", help="open in the default browser")
    parser.add_argument("--port", type=int, default=0, help="local port (default: any free port)")
    args = parser.parse_args()

    if args.check:
        from app.diagnostics import main as run_check

        return run_check()

    from app.ui.server import LunaServer, build_app

    settings = load_settings()
    if not settings.has_api_key:
        # Not an error: the UI shows the same setup steps. This is just a heads-up.
        print(missing_key_message(settings.env_file))
        print("\nLuna will still open so you can see the interface.\n")

    server = LunaServer(build_app(settings), port=args.port)
    server.start()
    print(f"Luna is running at {server.url}  (Ctrl+C to quit)")

    try:
        if not args.browser and _open_window(server.url):
            return 0
        webbrowser.open(server.url)
        threading.Event().wait()
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
