import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from app.config import DEFAULT_MODEL, load_settings, missing_key_message

FAKE_KEY = "AI" + "za" + "x" * 35  # built in pieces so secret scanners ignore the tests


def write_env(directory: Path, content: bytes, name: str = ".env") -> Path:
    path = directory / name
    path.write_bytes(content)
    return path


class SettingsTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self._tmp.name)
        patcher = mock.patch.dict(os.environ, {}, clear=True)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.addCleanup(self._tmp.cleanup)

    def test_missing_file_means_no_key(self):
        settings = load_settings(self.dir / ".env")
        self.assertFalse(settings.has_api_key)

    def test_placeholder_is_treated_as_missing(self):
        path = write_env(self.dir, b"GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE\n")
        self.assertFalse(load_settings(path).has_api_key)

    def test_empty_value_is_treated_as_missing(self):
        path = write_env(self.dir, b"GEMINI_API_KEY=\n")
        self.assertFalse(load_settings(path).has_api_key)

    def test_real_key_is_loaded(self):
        path = write_env(self.dir, f"GEMINI_API_KEY={FAKE_KEY}\n".encode())
        settings = load_settings(path)
        self.assertTrue(settings.has_api_key)
        self.assertEqual(settings.gemini_api_key, FAKE_KEY)

    def test_key_never_appears_in_repr_or_str(self):
        path = write_env(self.dir, f"GEMINI_API_KEY={FAKE_KEY}\n".encode())
        settings = load_settings(path)
        self.assertNotIn(FAKE_KEY, repr(settings))
        self.assertNotIn(FAKE_KEY, str(settings))

    def test_windows_notepad_bom_is_handled(self):
        path = write_env(self.dir, b"\xef\xbb\xbf" + f"GEMINI_API_KEY={FAKE_KEY}\r\n".encode())
        self.assertEqual(load_settings(path).gemini_api_key, FAKE_KEY)

    def test_quotes_and_spaces_are_stripped(self):
        path = write_env(self.dir, f'GEMINI_API_KEY="  {FAKE_KEY}  "\n'.encode())
        self.assertEqual(load_settings(path).gemini_api_key, FAKE_KEY)

    def test_os_environment_overrides_file(self):
        path = write_env(self.dir, b"GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE\n")
        with mock.patch.dict(os.environ, {"GEMINI_API_KEY": FAKE_KEY}):
            self.assertEqual(load_settings(path).gemini_api_key, FAKE_KEY)

    def test_load_does_not_write_into_os_environ(self):
        path = write_env(self.dir, f"GEMINI_API_KEY={FAKE_KEY}\n".encode())
        load_settings(path)
        self.assertNotIn("GEMINI_API_KEY", os.environ)

    def test_model_default_and_override(self):
        path = write_env(self.dir, b"GEMINI_API_KEY=\n")
        self.assertEqual(load_settings(path).gemini_model, DEFAULT_MODEL)
        path = write_env(self.dir, b"GEMINI_MODEL=gemini-test-model\n")
        self.assertEqual(load_settings(path).gemini_model, "gemini-test-model")

    def test_setup_message_explains_steps_without_a_key(self):
        message = missing_key_message(self.dir / ".env")
        self.assertIn("GEMINI_API_KEY", message)
        self.assertIn(".env", message)

    def test_setup_message_flags_notepad_txt_extension(self):
        write_env(self.dir, b"GEMINI_API_KEY=\n", name=".env.txt")
        message = missing_key_message(self.dir / ".env")
        self.assertIn(".env.txt", message)


if __name__ == "__main__":
    unittest.main()
