"""Browser-level tests of the real UI against the real local server (fake AI provider).
Skipped automatically if Playwright/Chromium isn't installed."""
import tempfile
import unittest
from pathlib import Path

from app.ai import AIProvider, AINetworkError, AIResponse
from app.chat import ChatStore
from app.config import Settings
from app.ui.server import LunaServer, build_app

try:
    from playwright.sync_api import sync_playwright
except ImportError:  # pragma: no cover
    sync_playwright = None

KEY = "AI" + "za" + "x" * 35


class FakeProvider(AIProvider):
    def __init__(self):
        self.fail = False

    def generate(self, messages, system_instruction=None):
        if self.fail:
            raise AINetworkError("Luna can't reach Gemini. Check your internet connection.")
        return AIResponse(text="Reply to: " + messages[-1].text)

    def check_connection(self):
        pass


@unittest.skipIf(sync_playwright is None, "playwright not installed")
class UiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            cls.pw = sync_playwright().start()
            cls.browser = cls.pw.chromium.launch()
        except Exception as error:  # no browser available
            raise unittest.SkipTest(f"Chromium unavailable: {error}")

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()

    def start(self, key=KEY):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.provider = FakeProvider()
        settings = Settings(gemini_api_key=key, env_file=Path(tmp.name) / ".env")
        app = build_app(settings, ChatStore(Path(tmp.name) / "chats.json"), self.provider)
        server = LunaServer(app)
        server.start()
        self.addCleanup(server.stop)
        # bypass_csp only so the test runner can use wait_for_function; the CSP itself is checked in test_server.py
        context = self.browser.new_context(viewport={"width": 1600, "height": 900}, bypass_csp=True)
        self.addCleanup(context.close)
        context.set_default_timeout(8000)
        page = context.new_page()
        self.errors = []
        page.on("pageerror", lambda e: self.errors.append(str(e)))
        page.on("console", lambda m: self.errors.append(m.text) if m.type == "error" else None)
        page.goto(server.url)
        page.wait_for_selector("#convo .welcome, #convo .msg")
        return page

    def say(self, page, text):
        page.fill("#input", text)
        page.press("#input", "Enter")

    def open_menu(self, page):
        page.click("#menuBtn")
        page.wait_for_selector("#drawer.open")

    def test_moon_is_gone_and_core_is_present(self):
        page = self.start()
        html = page.content().lower()
        self.assertNotIn("moon", html)
        self.assertEqual(page.locator(".core-dot").count(), 1)
        self.assertEqual(page.inner_text("#stateLabel"), "IDLE")
        self.assertEqual(self.errors, [])

    def test_chat_reply_and_state_returns_to_idle(self):
        page = self.start()
        self.say(page, "hello luna")
        page.wait_for_selector(".msg.luna:has-text('Reply to: hello luna')")
        self.assertEqual(page.inner_text("#stateLabel"), "IDLE")
        self.assertIn("READY", page.inner_text("#chipGemini"))
        self.assertEqual(self.errors, [])

    def test_menu_lists_all_chats_and_projects(self):
        page = self.start()
        self.say(page, "first question")
        page.wait_for_selector(".msg.luna:has-text('Reply to')")
        self.say(page, "new chat")
        page.wait_for_selector("#convo .welcome")
        self.say(page, "second question")
        page.wait_for_selector(".msg.luna:has-text('second question')")
        self.say(page, "new project called Robots")
        page.wait_for_selector("#convoTitle:has-text('ROBOTS')")
        self.open_menu(page)
        text = page.inner_text("#drawerList")
        self.assertIn("first question", text)
        self.assertIn("second question", text)
        self.assertIn("Robots", text)

    def test_saying_new_chat_and_new_project_opens_a_blank_chat(self):
        page = self.start()
        self.say(page, "something")
        page.wait_for_selector(".msg.luna:has-text('Reply to')")
        self.say(page, "new chat")
        page.wait_for_selector("#convo .welcome")
        self.assertEqual(page.locator("#convo .msg").count(), 0)
        self.assertIn("New chat ready", page.inner_text("#toast"))
        self.say(page, "new project")
        page.wait_for_selector("#convoTitle:has-text('PROJECT 1')")
        self.assertEqual(page.locator("#convo .msg").count(), 0)

    def test_open_old_chat_from_menu_restores_history(self):
        page = self.start()
        self.say(page, "alpha topic")
        page.wait_for_selector(".msg.luna:has-text('alpha topic')")
        self.say(page, "new chat")
        page.wait_for_selector("#convo .welcome")
        self.open_menu(page)
        page.click(".row[data-chat] .row-main:has-text('alpha topic')")
        page.wait_for_selector(".msg.you:has-text('alpha topic')")
        self.assertFalse(page.locator("#drawer.open").count())

    def test_rename_and_delete_chat_from_menu(self):
        page = self.start()
        self.say(page, "to be renamed")
        page.wait_for_selector(".msg.luna:has-text('Reply to')")
        self.open_menu(page)
        row = page.locator(".row[data-chat]", has_text="to be renamed")
        row.hover()
        row.locator("button[aria-label='Rename chat']").click()
        page.fill(".row-edit", "Better name")
        page.press(".row-edit", "Enter")
        page.wait_for_selector(".row[data-chat]:has-text('Better name')")
        row = page.locator(".row[data-chat]", has_text="Better name")
        row.hover()
        row.locator("button[aria-label='Delete chat']").click()
        page.click("#modalActions .danger")
        page.wait_for_function("!document.querySelector('#drawerList').textContent.includes('Better name')")
        self.assertIn("Chat deleted", page.inner_text("#toast"))
        self.assertEqual(page.locator("#convo .msg").count(), 0)  # a fresh blank chat is opened

    def test_search_filters_chats(self):
        page = self.start()
        self.say(page, "bananas")
        page.wait_for_selector(".msg.luna:has-text('bananas')")
        self.say(page, "new chat")
        page.wait_for_selector("#convo .welcome")
        self.say(page, "cars")
        page.wait_for_selector(".msg.luna:has-text('cars')")
        self.open_menu(page)
        page.fill("#search", "banana")
        page.wait_for_function("document.querySelectorAll('#drawerList .row[data-chat]').length === 1")
        self.assertIn("bananas", page.inner_text("#drawerList"))

    def test_missing_key_shows_setup_message_and_no_crash(self):
        page = self.start(key=None)
        self.assertIn("KEY MISSING", page.inner_text("#chipGemini"))
        self.assertIn("GEMINI_API_KEY", page.inner_text("#convo"))
        self.say(page, "hello")
        page.wait_for_selector("#stateLabel:has-text('ERROR')")
        self.assertEqual(page.input_value("#input"), "hello")  # text kept so nothing is lost
        self.assertEqual(self.errors, [])

    def test_gemini_failure_enters_error_state_and_keeps_text(self):
        page = self.start()
        self.provider.fail = True
        self.say(page, "will fail")
        page.wait_for_selector("#stateLabel:has-text('ERROR')")
        self.assertIn("can't reach Gemini", page.inner_text("#convo"))
        self.assertEqual(page.input_value("#input"), "will fail")
        self.assertEqual(page.locator(".msg.you").count(), 0)  # the failed message isn't shown as sent
        self.provider.fail = False
        page.press("#input", "Enter")
        page.wait_for_selector(".msg.luna:has-text('Reply to: will fail')")
        self.assertEqual(page.inner_text("#stateLabel"), "IDLE")

    def test_all_five_states_are_reachable_and_change_the_look(self):
        page = self.start()
        seen = {}
        for name in ["IDLE", "LISTENING", "THINKING", "SPEAKING", "ERROR"]:
            page.evaluate("n => window.Luna.setState(n)", name)
            self.assertEqual(page.inner_text("#stateLabel"), name)
            self.assertEqual(page.evaluate("document.body.dataset.state"), name)
            seen[name] = page.evaluate("getComputedStyle(document.body).getPropertyValue('--accent')").strip()
        self.assertEqual(len(set(seen.values())), 5)  # every state has its own colour

    def test_stop_button_only_visible_while_speaking(self):
        page = self.start()
        self.assertTrue(page.locator("#stopBtn").is_hidden())
        page.evaluate("window.Luna.setState('SPEAKING')")
        self.assertTrue(page.locator("#stopBtn").is_visible())
        page.click("#stopBtn")
        self.assertEqual(page.inner_text("#stateLabel"), "IDLE")

    def test_user_text_is_never_interpreted_as_html(self):
        page = self.start()
        self.say(page, "<img src=x onerror='window.__pwned=1'>")
        page.wait_for_selector(".msg.luna")
        self.assertIsNone(page.evaluate("window.__pwned"))
        self.assertIn("<img", page.inner_text("#convo"))

    def test_keyboard_shortcuts(self):
        page = self.start()
        page.keyboard.press("Control+m")
        page.wait_for_selector("#drawer.open")
        page.keyboard.press("Escape")
        page.wait_for_function("!document.querySelector('#drawer').classList.contains('open')")
        page.click("#menuBtn")
        page.keyboard.press("Escape")
        page.keyboard.press("Control+l")
        self.assertEqual(page.evaluate("document.activeElement.id"), "input")

    def test_settings_dialog_never_shows_key_and_can_test(self):
        page = self.start()
        self.open_menu(page)
        page.click("#settingsBtn")
        page.wait_for_selector("#modal:not([hidden])")
        page.click("text=TEST CONNECTION")
        page.wait_for_selector(".result.ok")
        self.assertNotIn(KEY, page.content())

    def test_system_panel_fills_in(self):
        page = self.start()
        page.wait_for_function("document.querySelector('#vRam').textContent.includes('%')", timeout=8000)

    def test_layout_fits_common_laptop_sizes_without_page_scroll(self):
        page = self.start()
        for w, h in [(1920, 1080), (1366, 768), (1280, 720)]:
            page.set_viewport_size({"width": w, "height": h})
            page.wait_for_timeout(150)
            overflow = page.evaluate("document.documentElement.scrollHeight - window.innerHeight")
            self.assertLessEqual(overflow, 1, f"{w}x{h} overflows by {overflow}px")
            box = page.locator("#form").bounding_box()
            self.assertLessEqual(box["y"] + box["height"], h)


if __name__ == "__main__":
    unittest.main()
